import socket

# Listening settings
host = ""  # Listen on all interfaces
port = 12345

# Create a UDP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((host, port))

print(f"Listening for broadcasts on port {port}...")

# Receive the file data
data, addr = sock.recvfrom(65535)
print(f"Received data from {addr}")

# Save the received file
with open("received_script.py", "wb") as file:
    file.write(data)
    print("File saved as 'received_script.py'")
sock.close()
