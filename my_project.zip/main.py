import socket

# File to send
file_path = "script.py"

# Broadcast settings
broadcast_ip = "255.255.255.255"
port = 12345

# Create a UDP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

with open(file_path, "rb") as file:
    data = file.read()

# Send the file data
sock.sendto(data, (broadcast_ip, port))
print(f"File broadcasted to {broadcast_ip}:{port}")

